
default_action :nothing

actions :apply

attribute :user, :kind_of => String, :name_attribute => true, :required => true
